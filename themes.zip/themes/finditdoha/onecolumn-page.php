<?php
/**
 * Template Name: Full Width
 *
 * A custom page template without sidebar.
 *
 * The "Template Name:" bit above allows this to be selectable
 * from a dropdown menu on the edit page screen.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>		 
			
<div class="form_part width100">	
<div class="container">		 
			 <div id="content">			 
			 <?php get_template_part( 'loop', 'page' ); ?>
			 </div>
           </div>         
</div>






	

<?php get_footer(); ?>

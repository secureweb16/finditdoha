<?php
/**
 * The loop that displays posts.
 *
 * The loop displays the posts and the post content. See
 * http://codex.wordpress.org/The_Loop to understand it and
 * http://codex.wordpress.org/Template_Tags to understand
 * the tags used in it.
 *
 * This can be overridden in child themes with loop.php or
 * loop-template.php, where 'template' is the loop context
 * requested by a template. For example, loop-index.php would
 * be used if it exists and we ask for the loop with:
 * <code>get_template_part( 'loop', 'index' );</code>
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>



    <?php if ( ! have_posts() ) : ?>
	<div id="post-0" class="post error404 not-found">
	  <h2 class="entry-title"><?php _e( 'Not Found', 'twentyten' ); ?></h2>
	    <div class="entry-content">
	    <p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyten' ); ?></p>
	    <?php get_search_form(); ?>
	    </div>
	</div>
<?php endif; ?>

<?php while ( have_posts() ) : the_post(); ?>

	<?php if ( ( function_exists( 'get_post_format' ) && 'gallery' == get_post_format( $post->ID ) ) || in_category( _x( 'gallery', 'gallery category slug', 'twentyten' ) ) ) : ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
			<h2><a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'twentyten' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark"><?php the_title(); ?></a></h2>

			<div class="entry-meta">
			<?php twentyten_posted_on(); ?>
			</div><!-- .entry-meta -->
						
		</div><!-- #post-## -->

<?php /* How to display posts of the Aside format. The asides category is the old way. */ ?>

	<?php elseif ( ( function_exists( 'get_post_format' ) && 'aside' == get_post_format( $post->ID ) ) || in_category( _x( 'asides', 'asides category slug', 'twentyten' ) )  ) : ?>
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<?php if ( is_archive() || is_search() ) : // Display excerpts for archives and search. ?>
			
		<?php else : ?>
			
		<?php endif; ?>

			<div class="entry-utility">
				<?php twentyten_posted_on(); ?>
				<span class="meta-sep">|</span>
				
				<?php edit_post_link( __( 'Edit', 'twentyten' ), '<span class="meta-sep">|</span> <span class="edit-link">', '</span>' ); ?>
			</div><!-- .entry-utility -->
		</div><!-- #post-## -->

<?php /* How to display all other posts. */ ?>

	<?php else : ?>
	
	
		<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>		
					

	<?php if ( is_archive() || is_search() ) : // Only display excerpts for archives and search. ?>
			<div class="entry-summary archivepost">
            <h3><a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'twentyten' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">                <?php the_title(); ?></a>
              </h3>
				<?php the_excerpt(); ?>
				<a  href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent link to <?php the_title_attribute(); ?>">Read More...</a>
			</div><!-- .entry-summary -->
	<?php else : ?>           
            
        <div class="blogpost">              
          <div class="row">				
            <div class="col-md-12">                
              
              <div class="postimg">
              <a  href="<?php the_permalink(); ?>" rel="bookmark"><?php the_post_thumbnail( $size, $attr ); ?></a>				
              </div>
              
              <h3><a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'twentyten' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark">                <?php the_title(); ?></a>
              </h3>
              
              <div class="post-meta">
              <span><i class="glyphicon glyphicon-calendar"></i><?php echo get_the_date(); ?></span><span><i class="glyphicon glyphicon-user"></i> <?php the_author(); ?></span><span><i class="glyphicon glyphicon-align-left"></i><?php the_category( ', ' ); ?></span>
              </div>
                     
              <?php the_excerpt(); ?>
            
            </div>            
          </div>            
        </div>  
          
				
		<?php wp_link_pages( array( 'before' => '<div class="page-link">' . __( 'Pages:', 'twentyten' ), 'after' => '</div>' ) ); ?>														
			
	<?php endif; ?>		
				
		</div><!-- #post-## -->		
		

		<?php comments_template( '', true ); ?>

	<?php endif; // This was the if statement that broke the loop into three parts based on categories. ?>

<?php endwhile; // End the loop. Whew. ?>

<div id="pagination">

<div class="page-numbers">


<?php
global $wp_query;

$big = 999999999; // need an unlikely integer

echo paginate_links( array(
	'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	'format' => '?paged=%#%',
	'current' => max( 1, get_query_var('paged') ),
	'total' => $wp_query->max_num_pages
) );
?>

</div>
</div>
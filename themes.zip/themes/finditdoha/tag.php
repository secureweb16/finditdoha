<?php
/**
 * The template for displaying Tag Archive pages.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>		   
			
     <div id="content" role="main">
	 <h1 class="page-title">
	 <?php printf( __( 'Tag Archives: %s', 'twentyten' ), '<span>' . single_tag_title( '', false ) . '</span>' ); ?></h1>
     <?php get_template_part( 'loop', 'tag' );?>
	 </div>		

<?php get_sidebar(); ?>
<?php get_footer(); ?>

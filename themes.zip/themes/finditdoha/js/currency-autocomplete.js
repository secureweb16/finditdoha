$(function(){
  var currencies = [
    { value: 'Where can I find an AV receiver?', data: 'AFN' },
    { value: 'Which store has whole allspice in Doha?', data: 'ALL' },
    { value: 'Where can I find teriyaki sauce?', data: 'DZD' },
    { value: 'Where do you find a modern carpet?', data: 'EUR' },
    { value: 'Where to find essential oils? ', data: 'AOA' },    
  ];
  
  // setup autocomplete function pulling from currencies[] array
  $('#qa-question').autocomplete({
    lookup: currencies,
    onSelect: function (suggestion) {      
      
    }
  });  

});
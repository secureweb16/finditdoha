<?php
/**
 * The Sidebar containing the primary and secondary widget areas.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>
	  
	  <div class="col-md-4 col-sm-12">  
        <div class="sidebar">		 
		  
		  <?php if(is_page()) :?>
          <div class="pagesidebar">
		  <?php dynamic_sidebar( 'pagesidebar-widget-area' ); ?>
          </div>
          <?php endif ;?>		   
           
          <?php if(is_home()  ||  is_single()  ||  is_category()  ||  is_archive()  ||  is_author()) :?>
          <div class="blogsidebar">
		  <?php dynamic_sidebar( 'blogsidebar-widget-area' ); ?>
          </div>
          <?php endif ;?>
         
        </div>
	  </div>    
    
    </div>
    <!--End Row-->




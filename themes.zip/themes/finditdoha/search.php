<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>
		
    <div id="content" role="main" class="container">
      
	  <?php if ( have_posts() ) : ?>
	  <h4 class="page-title"><?php printf( __( 'Search results for: %s', 'twentyten' ), '<span>' . get_search_query() . '</span>' ); ?></h4>
	  <?php get_template_part( 'loop', 'search' ); ?>
      <?php else : ?>
	
      <div id="post-0" class="post no-results not-found searchpart">
        <h2 class="entry-title"><?php _e( 'Nothing Found', 'twentyten' ); ?></h2>
        <div class="entry-content">
	    <p><span><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'twentyten' ); ?></span></p>     
	    </div>
	  </div>
      <?php endif; ?>
	
    </div>            

<?php get_footer(); ?>

<?php
/*
Template Name: Home Page
*/

get_header(); ?>
           
	<div class="container">
<div class="row">
  <div class="col-md-8 col-sm-12">
    <div id="content">
      <div class="main_div">
        <div class="question_mark"> <img src="images/question-mark(1).png"> </div>
        <div class="circel_bg"> <img src="images/circel.jpg">
          <div class="input_box">
            <input name="question" placeholder="Enter your Question...." type="text">
            <a href=""><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>

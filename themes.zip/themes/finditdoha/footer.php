<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after. Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>		  			    
	 
    <footer>
	<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">		
					<div class="footer_bg">
						<img class="topbgfooter" style="padding-top: 132px;float: left;left: -15px;position: relative;" src="<?php bloginfo('template_url'); ?>/images/footercircel.jpg">
						<img class="bottombgfooter" style="float: right;padding-top: 160px;position: relative;right: -15px;" src="<?php bloginfo('template_url'); ?>/images/footercorner.jpg">
						<?php dynamic_sidebar('copyright'); ?>
					</div>
				</div>
			</div>
		</div>
	</footer>   
 

   	
<?php wp_footer();?>

</body>
</html>
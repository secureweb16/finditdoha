<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>

<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php
	
	global $page, $paged;
	wp_title( '|', true, 'right' );
	bloginfo( 'name' );
	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";
	if ( $paged >= 2 || $page >= 2 )
		echo ' | ' . sprintf( __( 'Page %s', 'twentyten' ), max( $paged, $page ) );
	?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<?php if ( is_front_page() || is_home() ) { }else{ ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/style.css" />
<?php } ?>
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('stylesheet_directory'); ?>/images/favicon.ico" />

<!--Start Boopstrap Social Links Css-->
<link href="<?php bloginfo( 'template_url' ); ?>/social-font/css/font-awesome.css" rel="stylesheet" type="text/css">
<!--End Boopstrap Social Links Css-->

<!--Start Font Css-->
<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic' rel='stylesheet' type='text/css'>
<!--End Font Css-->
<link href="<?php bloginfo( 'template_url' ); ?>/css/main.css" rel="stylesheet" type="text/css" media="all">
<!--Start Boopstrap Css-->
<link href="<?php bloginfo( 'template_url' ); ?>/css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!--End Boopstrap Css-->

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
<![endif]-->

<script  type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" 
         src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<!--Start Boopstrap JavaScript-->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
<!--End Boopstrap JavaScript Css-->

<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.autocomplete.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/currency-autocomplete.js"></script>


<?php	
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );	 	 
	wp_head();	
?>
</head>

<body <?php body_class(); ?>>
		<div class="top_header width100">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="topheader_left">
                            <?php dynamic_sidebar('topleft'); ?>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 ">
                            <div class="topheader_right">
                             <?php dynamic_sidebar('topright'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
		<div class="logo width100">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="logo_img">
						<a title="<?php echo esc_attr( get_bloginfo()); ?>" href="<?php echo get_site_url(); ?>"><img src='<?php echo esc_url( get_theme_mod( 'themeslug_logo' ) ); ?>' alt='<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>'></a>
					</div>
				</div>
			</div>
		</div>
	</div>   
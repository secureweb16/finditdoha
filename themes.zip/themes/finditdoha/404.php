<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>

<div class="container">	
	<div id="content" class="errorpad">
	  <div class="row">			
		
		<div class="col-md-5 col-sm-5 text-center">				
          <div class="lefterror">
		    <img src="<?php bloginfo( 'template_url' ) ?>/images/404_error.png"/>
		    <div class="clearboth"></div>			
		  </div>		
		</div>			
			
		<div class="col-md-7 col-sm-7 text-center">							
		  <div class="righterror">
		  <h1>We Are Sorry</h1>							
		  <p>The page you are looking for might have been removed,
		  had its name changed, or is temporarily unavailable,
		  <br />Please email us at: <a href="info@gmail.com">info@gmail.com</a>
		  </p>           
		  <h4><a class="orange-btn" href="<?php echo get_site_url(); ?>">Continue to our Website</a></h4>		
		  </div>
		  
		</div>	
		
      </div>
</div>
</div>
	
	<script type="text/javascript">
		// focus on search field after it has loaded
		document.getElementById('s') && document.getElementById('s').focus();
	</script>

<?php get_footer(); ?>